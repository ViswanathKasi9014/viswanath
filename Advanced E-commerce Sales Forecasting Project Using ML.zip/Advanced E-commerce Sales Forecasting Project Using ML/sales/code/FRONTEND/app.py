from flask import Flask, render_template, request
import joblib  # For loading the saved model

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def prediction():
    if request.method == "POST":
        # Retrieve input values from the form
        try:
            ShipDate = int(request.form['ShipDate'])
            ShipMode = int(request.form['ShipMode'])
            Month_Num = int(request.form['Month_Num'])
        except ValueError:
            # Handle cases where input is not a valid integer
            return render_template("prediction.html", results="Invalid input. Please enter valid numbers.")

        # Prepare input for the model
        new_values = [[ShipDate, ShipMode, Month_Num]]

        try:
            # Load the pre-trained model
            model = joblib.load("Models/decision.joblib")
            # Make a prediction
            pred = model.predict(new_values)
            prediction_result = f"The prediction is: {pred[0]}"
        except Exception as e:
            # Handle cases where the model fails to load or predict
            return render_template("prediction.html", results=f"Error: {e}")

        # Render the template with prediction results
        return render_template("prediction.html", results=prediction_result)

    # Render the form for GET requests
    return render_template("prediction.html", results=None)

if __name__ == "__main__":
    app.run(debug=True)
