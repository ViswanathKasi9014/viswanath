package com.example.fred.securitycenter;

/**
 * Created by NgocTri on 4/11/2016.
 */
public class Common {
    static final String SERVICE_API_URL = "http://10.0.2.2/ss/ws.php";
    static final int RESULT_SUCCESS = 0;
    static final int RESULT_ERROR= 1;
    static final int RESULT_USER_EXISTS = 2;
    static final String TAG_SUCCESS = "success";
    static final String TAG_STUFF = "stuff";
}
