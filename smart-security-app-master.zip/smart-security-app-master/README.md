# smart-security-app
Android Application
